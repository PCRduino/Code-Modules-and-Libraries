/* Serial Keyboard Input Functions (SKIF)
   SKIF Library Conversion 
   by Brian Patton 7/13/2020.  www.pattonrobotics.com
   The SKIF module was orginally written by:
    
   c.d.odom 10.19.14 www.pcrduino.com
   originally a module that houses a variety of homemade functions to grab keyboard input

*/

#ifndef SKIF_h
#define SKIF_h
#include "Arduino.h"


class SKIF
{
public:
  byte readByte();
  char readChar();
  String readString();
  int readInt();
  float readFloat();

private:


};
#endif