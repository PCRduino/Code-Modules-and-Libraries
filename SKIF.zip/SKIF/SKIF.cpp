
/* SKIF
 c.d.odom 10.19.14
 a sketch that houses a variety of homemade functions to grab keyboard input
*/
// HISTORY:
// Brian Patton - Added 2ms delay in readString to make sure the buffer had time to refill 7/13/2020

#include "SKIF.h"
#include "Arduino.h"



byte SKIF::readByte(){
  while (Serial.available() == 0);      // pause indefinately until the serial port has data.
  byte getByte = Serial.read();         // grab a byte (character) stored in the serial port buffer
  delay(2);							// Added to slow it down and not skip the streaming characters
    // clean up the keyboard buffer in case user enters more than one character:
  while (Serial.available() > 0)  { // added the clearing of the buffer on 7/13/2020
    char junk = Serial.read() ;       // empty the keyboard buffer one character at a time
  }   
  delay(2);							// Added to slow it down and not skip the streaming characters  
  return getByte;
}

char SKIF::readChar(){
  while (Serial.available() == 0);      // pause indefinately until the serial port has data.
  char getChar = Serial.read();         // grab a character (byte) stored in the serial port buffer
  delay(2);							// Added to slow it down and not skip the streaming characters

  // clean up the keyboard buffer in case user enters more than one character:
  while (Serial.available() > 0)  { 
    char junk = Serial.read() ;       // empty the keyboard buffer one character at a time
  }   
  delay(2);							// Added to slow it down and not skip the streaming characters  
  return getChar;
}


String SKIF::readString(){
  String buildString = "";

  while (Serial.available() == 0);      // pause indefinately until the serial port has data.
  delay(2);							// Added to slow it down and not skip the streaming characters
  // loop while there are bytes in the serial port 
  while (Serial.available() > 0){
	delay(2);							// Added to slow it down and not skip the streaming characters
    char getChar = Serial.read();       // grab a character (byte) stored in the serial port buffer
    if (getChar == '\n'){               // if the character is a carriage return (ENTER) ...
      // ... do nothing ... the input textbox is now empty
    }
    else{
      buildString += getChar;      // build the string one character at a time
    }
  }
  delay(2);							// Added to slow it down and not skip the streaming characters
  return buildString;
}

int SKIF::readInt(){
  while (Serial.available() == 0);                     // pause indefinately until the serial port has data.
  delay(2);							// Added to slow it down and not skip the streaming characters
  int getInt = Serial.parseInt();                      // grab an integer from th the serial port buffer
  // note delay with parseInt!  try entering a letter

  // parse sometimes leaves junk characters, so this cleans up the keyboard buffer:
  while (Serial.available() > 0)  { 
    char junk = Serial.read() ;     // empty the keyboard buffer one character at a time
  }    
  delay(2);							// Added to slow it down and not skip the streaming characters  
  return getInt;
}

float SKIF::readFloat(){
  // NB: not accurate for large numbers.  For more precision, use snprintf
  // NB: does not recognize scientific notation

  while (Serial.available() == 0);                         // pause indefinately until the serial port has data.
  float getFloat = Serial.parseFloat();                    // grab a floating number from the serial port buffer
  // note delay with parseFloat!  try entering a letter

  // parse sometimes leaves junk characters, so this cleans up the keyboard buffer:
  while (Serial.available() > 0)  {
	delay(2);							// Added to slow it down and not skip the streaming characters
    char junk = Serial.read() ;       // empty the keyboard buffer one character at a time
  }   
  delay(2);							// Added to slow it down and not skip the streaming characters
  return getFloat;  
}